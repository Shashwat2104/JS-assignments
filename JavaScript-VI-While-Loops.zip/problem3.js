let i=1;
while(i<=30){
  if(i%3==0){
    console.log(i)
  }i++;
}